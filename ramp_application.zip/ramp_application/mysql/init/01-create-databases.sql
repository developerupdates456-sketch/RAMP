-- Create databases
CREATE DATABASE IF NOT EXISTS oem_integration CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
