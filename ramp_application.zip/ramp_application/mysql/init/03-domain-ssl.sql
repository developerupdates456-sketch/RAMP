CREATE TABLE IF NOT EXISTS domain_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    domain_name VARCHAR(253) NOT NULL,
    certificate_path VARCHAR(500) NOT NULL,
    private_key_path VARCHAR(500) NOT NULL,
    certificate_expiry DATETIME NULL,
    https_enabled TINYINT(1) DEFAULT 0,
    last_applied_at DATETIME NULL,
    created_by VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_domain_settings_domain (domain_name),
    INDEX idx_domain_settings_created_at (created_at)
);

CREATE TABLE IF NOT EXISTS domain_settings_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    domain_name VARCHAR(253) NULL,
    action VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    details TEXT NULL,
    created_by VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_domain_settings_history_domain (domain_name),
    INDEX idx_domain_settings_history_created_at (created_at)
);
