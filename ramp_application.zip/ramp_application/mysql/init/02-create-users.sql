-- Note: User is created by MySQL container from MYSQL_USER/MYSQL_PASSWORD
-- This script grants additional privileges if needed

-- Grant specific privileges for backup
GRANT LOCK TABLES, SELECT ON oem_integration.* TO 'oem_app'@'%';

-- Flush privileges
FLUSH PRIVILEGES;
