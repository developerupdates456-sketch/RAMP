-- Phase 3a: Least-privilege runtime DB user.
-- The MySQL container auto-grants ALL PRIVILEGES ON oem_integration.* to oem_app
-- when MYSQL_USER/MYSQL_DATABASE are set. That grant includes DROP and GRANT OPTION,
-- which the application never needs. Tighten to the minimal set required by the app
-- (create_tables.py performs CREATE/ALTER/ADD INDEX only; no DROP, no GRANT, no user mgmt).

-- Revoke the broad auto-grant (also covers the earlier LOCK TABLES/SELECT add).
REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'oem_app'@'%';

-- Re-grant precise, least-privilege set. No DROP, no GRANT OPTION, scoped to the app DB.
GRANT SELECT, INSERT, UPDATE, DELETE,
      CREATE, ALTER, INDEX, REFERENCES, EXECUTE,
      LOCK TABLES
  ON oem_integration.* TO 'oem_app'@'%';

FLUSH PRIVILEGES;
