#!/bin/sh
# Entrypoint for the RMM backend image.
#
# Runs unprivileged (the image sets USER app) and does only what a container
# needs before handing control to its role command:
#   api     -> gunicorn  -c gunicorn.conf.py backend.wsgi:app
#   worker  -> python -m backend.worker
#   migrate -> python -m backend.migrations upgrade
#
# It deliberately does NOT run migrations, create the database, or wait for
# MySQL. Compose already gates startup on the mysql healthcheck, and the
# migration advisory lock exists to serialise explicit invocations -- doing it
# implicitly here would reintroduce the race that splitting the roles removed.
set -eu

# First start: publish the files baked into the image into the (empty) uploads
# volume. -n never overwrites anything the operator has uploaded since.
if [ -d /app/uploads-init ] && [ -d /app/uploads ]; then
    cp -rn /app/uploads-init/. /app/uploads/ 2>/dev/null || true
fi

# Fail fast and loudly if the writable paths are not writable. On a
# read_only root with a mis-owned bind mount, the failure otherwise surfaces
# as a mysteriously unhealthy container long after startup.
for dir in "${UPLOAD_FOLDER:-/app/uploads}" "${LOG_DIR:-/app/logs}"; do
    if ! mkdir -p "$dir" 2>/dev/null; then
        echo "FATAL: cannot create $dir (uid=$(id -u)). Check the volume is" >&2
        echo "       present and owned by the container user." >&2
        exit 1
    fi
    if [ ! -w "$dir" ]; then
        echo "FATAL: $dir is not writable (uid=$(id -u))." >&2
        exit 1
    fi
done

exec "$@"
